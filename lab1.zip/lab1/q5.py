str1="abc"
str2="cde"

set1={}
set1=set(str1)
set2={}
set2=set(str2)

print(set1.intersection(set2))
