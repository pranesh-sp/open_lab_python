ls=["ab","bc","cd"]
c=input("enter c")

for i in ls:
    if(i[0]==c):print(i)