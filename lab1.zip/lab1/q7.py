list1=[]
num=int(input("number: "))
tup=(num,num*num)
print(tup)
list1.append(tup)
print(list1)