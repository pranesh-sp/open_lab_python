from collections import Counter

st1="abc"
st2="cba"



if(Counter(st1)==Counter(st2)):print("anagram")
else: print("not anagram")
